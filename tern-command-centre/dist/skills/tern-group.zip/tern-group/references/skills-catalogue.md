# tern-os skills catalogue (89 skills, generated 2026-10-26)

Each skill's full body is `tern-os/.claude/skills/<id>/SKILL.md` on the Mac (Claude Code loads it there). On other surfaces Max works from this summary and the carrier's mandate. Reviewed every Monday in the Weekly Group Review (Fit / Stretch / Gap → Keep / Update / Upgrade / Absorb / Hire).

| Skill | What it does | Carried by |
|---|---|---|
| Legal | Contract review, drafting, compliance checks, risk assessment | Vikram Desai |
| agent-protocol | Inter-agent communication protocol for C-suite agent teams - invocation syntax, loop prevention, isolation rules | Grace Liu, Max |
| api-builder | Designs, builds, documents and tests production-grade REST, GraphQL and gRPC APIs | Aarav Mehta, Grace Liu, Sameer Rathi, Tobias Lindgren |
| app-builder | Full-stack application builder — frontend, backend, database, auth and deployment | Aarav Mehta, Grace Liu, Jonas Weber, Sameer Rathi, Tobias Lindgren |
| astro | Vedic, Western & Chinese astrology, numerology, tarot, vastu, horoscopes | — |
| atlassian-admin | Administers Jira, Confluence, Bitbucket, Trello — users, permissions, security | Karthik Subramanian |
| atlassian-templates | Creates and manages Jira/Confluence templates, blueprints and layouts | Karthik Subramanian |
| automation-designer | No-code workflow design for n8n, Make.com and Zapier | Lena Hoffmann, Liam O'Brien, Marco Ferreira, Pooja Deshpande, Samuel Reyes |
| bd-consultant | BPO/IT business development - sales decks, RFP/RFI responses, solution proposals | Elena Fischer, Meera Kulkarni, Rajeev Bhatia, Rohan Kapoor, Shalini Venkataraman |
| board-deck-builder | Assembles board and investor decks pulling from all C-suite roles | Diego Santos |
| board-meeting | 6-phase multi-agent board deliberation protocol for strategic decisions | Max |
| brainstorming | Creative ideation partner for generating, expanding and refining ideas | Ethan Cole, Julian Moreau, Kavitha Ramanathan |
| c-level-advisor | 10 C-level advisory agents - CEO, CTO, COO, CPO, CMO, CFO, CRO, CISO, CHRO | — |
| ceo-advisor | Executive strategy, organizational development, stakeholder management | Diego Santos, Meera Kulkarni, Shalini Venkataraman |
| cfo-advisor | Financial modeling, unit economics, fundraising, cash management | Priya Nair |
| change-management | ADKAR-based change rollout - communication templates, resistance patterns | Sneha Pillai |
| chief-ai-officer-advisor | Model build-vs-buy, AI risk classification, EU AI Act navigation | Amara Okonkwo |
| chief-customer-officer-advisor | Retention decomposition, churn taxonomy, customer segmentation | Chloe Martin, Nitin Waghmare |
| chief-data-officer-advisor | Data product strategy - warehouse vs lakehouse vs mesh, training-data rights | Liam O'Brien |
| chief-of-staff | C-suite orchestration - routes questions, triggers board meetings, synthesizes | Hannah Brooks, Max |
| chro-advisor | Hiring strategy, compensation design, org structure, culture, retention | Ananya Iyer, Shalini Venkataraman |
| chrome-extension-builder | Browser extensions with Manifest V3 - popup UI, scripts, storage | Rohit Saxena |
| ciso-advisor | Risk in dollars, SOC 2 / ISO 27001 / HIPAA / GDPR compliance roadmaps | Amara Okonkwo, Arjun Khanna, Thomas Becker |
| cmo-advisor | Brand positioning, growth model design, marketing budget and org | Sofia Rossi |
| company-os | The meta-framework for how a company runs - EOS, Scaling Up, OKR-native | Diego Santos, Max |
| competitive-intel | Competitor tracking feeding positioning, battlecards, roadmap | Kavya Reddy |
| confluence-expert | Spaces, knowledge bases, documentation, permissions, page templates | Karthik Subramanian |
| content-repurposer | Turns one piece of content into multi-platform posts | Maya Lindqvist |
| context-engine | Loads and manages company context for all C-suite advisors | Max |
| coo-advisor | Process design, OKR execution, operational cadence, scaling playbooks | Sneha Pillai |
| cpo-advisor | Product vision, portfolio strategy, product-market fit, product org | Ethan Cole, Jonas Weber, Vivek Anand |
| cro-advisor | Revenue forecasting, sales model design, pricing, NRR, team scaling | Rohan Kapoor |
| cs-onboard | Founder onboarding interview capturing company context across 7 dimensions | — |
| cto-advisor | Technical debt, engineering scaling, architecture decisions | Aarav Mehta |
| culture-architect | Culture as operational behavior - values-to-behaviors translation | Ananya Iyer |
| dashboard-builder | Interactive HTML or Excel dashboards for analysts and business users | Felix Andersson, Jonas Weber, Lena Hoffmann, Liam O'Brien, Neha Joshi, Pranav Bhatt, Samuel Reyes |
| data-analyst | Structured & unstructured data analysis and summarization | Arvind Menon, Deepa Balakrishnan, Felix Andersson, Kavitha Ramanathan, Lena Hoffmann, Liam O'Brien, Nitin Waghmare, Pooja Deshpande, Pranav Bhatt |
| data-report-generator | Full analysis-to-report pipeline for CSV/Excel data | Neha Joshi |
| data-report | Data reports from CSV/Excel in PDF, Excel, PowerPoint or Markdown | Neha Joshi, Priya Nair |
| database-designer | Schemas, ERDs, migrations, query optimization — PostgreSQL/Supabase | Aarav Mehta, Tobias Lindgren |
| decision-logger | Two-layer memory for board decisions - transcripts + approved decisions | Max |
| devops-builder | GitHub Actions, Dockerfiles, deployment configs, environments | Aarav Mehta, Pranav Bhatt |
| doc-generator | Turns unstructured information into polished SOPs and documents | Arvind Menon, Deepa Balakrishnan, Maya Lindqvist, Sanjay Kulshreshtha, Sophie Laurent |
| email-writer | Composes fresh emails and crafts replies professionally | Aisha Bello, Marco Ferreira, Nitin Waghmare, Pooja Deshpande, Rohan Kapoor |
| finance | Journal entries, reconciliations, statements, DCF, valuations, SOX | Arvind Menon, Meera Kulkarni, Priya Nair, Sanjay Kulshreshtha |
| fitness | Dietitian + personal trainer - diet plans (Indian regional), training | Carlos Rivera, Dr. Vikas Thakur |
| founder-coach | Founder archetypes, delegation frameworks, energy management | — |
| frontend-design | Pixel-perfect responsive accessible UIs from wireframes or descriptions | Ethan Cole, Hana Kobayashi, Jonas Weber |
| general-counsel-advisor | Contract review (MSA, SaaS, NDA, DPA), IP strategy, term sheets | Vikram Desai |
| get-video-highlights | Extracts highlights from video content | Noah Bennett |
| infographic | Data-rich HTML infographics with deep web research, exported PNG/PDF | Jonas Weber |
| instagram-creator | Carousels, Reel scripts, Stories, bio and hashtag strategy | Riya Malhotra |
| internal-narrative | One coherent company story across employees, investors, customers | Sofia Rossi |
| intl-expansion | Market selection, entry modes, localization, regulatory compliance | Kavya Reddy |
| jira-expert | Projects, JQL, workflows, custom fields, automation, reporting | Karthik Subramanian |
| legal-advisor | Contracts, agreements, compliance, policies, disputes, regulations | Elena Fischer, Sanjay Kulshreshtha, Thomas Becker, Vikram Desai |
| linkedin-creator | Professional posts, articles, profile optimization, B2B strategy | Aisha Bello, Riya Malhotra |
| ma-playbook | M&A - due diligence, valuation, integration, deal structure | Kavya Reddy |
| market-opportunities | Multi-agent research pipeline - web research, scraping, analysis | Kavya Reddy, Vivek Anand |
| marketing | Campaign strategy, copy, content calendars, SEO, email design | Hana Kobayashi, Samuel Reyes, Sofia Rossi |
| meeting-analyzer | Surfaces behavioral patterns and coaching feedback from transcripts | Hannah Brooks, Julian Moreau |
| mobile-app-builder | React Native, Flutter, Swift/SwiftUI apps with navigation and state | Ethan Cole, Lucas Meyer, Tobias Lindgren |
| nutrition | Meal plans, macros, calorie tracking, Indian regional cuisine | Carlos Rivera |
| org-health-diagnostic | 8-dimension traffic-light organizational health check | Ananya Iyer, Karthik Subramanian |
| pdf | Professional PDF documents from any content, markdown or data | Sophie Laurent |
| pm-skills | 6 project-management agents - senior PM, scrum master, Jira, Confluence | Nitin Waghmare, Sneha Pillai |
| presentation-maker | Polished PPTX from PPT, Word, PDF, Excel or plain instructions | Deepa Balakrishnan, Shalini Venkataraman, Dr. Sunita Raghavan |
| productivity | Task management, daily planning, weekly reviews, focus sessions | Hannah Brooks, Max |
| remotion | Production-grade programmatic video with React and Remotion | Noah Bennett |
| resume-builder | Modern ATS-optimized resumes from any input incl. LinkedIn | — |
| resume | ATS-optimized resumes from PDF, DOCX, text or conversation | Aisha Bello, Marco Ferreira |
| sales | Prospect research, call prep, pipeline review, outreach, battlecards | Elena Fischer, Marco Ferreira, Meera Kulkarni, Rajeev Bhatia, Rohan Kapoor, Samuel Reyes |
| scenario-war-room | Cross-functional what-if modeling for compound adversity | Kavya Reddy |
| scrum-master | Sprint planning, velocity tracking, retrospectives, agile coaching | Sneha Pillai |
| senior-pm | Enterprise portfolio management, quantitative risk, resourcing | Sneha Pillai |
| social-media-analytics | Engagement analysis, posting times, growth tracking | Riya Malhotra |
| social-media-manager | Calendars, platform-native posts, viral hooks, Reels scripts | Riya Malhotra |
| strategic-alignment | Cascades strategy from boardroom to individual contributor | Diego Santos |
| streamlit-builder | Streamlit data apps and internal tools with auth and DB integration | Liam O'Brien |
| teacher | ICSE curriculum assistant - board-pattern papers, marking schemes | Deepa Balakrishnan, Elena Petrova, Farah Siddiqui, Isabel Moreno, Julian Moreau, Kavitha Ramanathan, Manoj Deshpande, Oliver Hughes, Rohit Saxena, Dr. Sunita Raghavan, Vinod Kulkarni |
| team-communications | 3P updates, newsletters, incident reports, leadership updates | Hannah Brooks |
| test-builder | Test generation and QA - pytest, Jest, Playwright, manual plans | Aarav Mehta, Ines Fischer, Pranav Bhatt, Tobias Lindgren |
| today | Morning brief - Notion + Todoist tasks, Gmail/iCloud mail, calendar | Max |
| travel | Itineraries, visas, transport — domestic and international | — |
| twitter-creator | Viral threads, tweet storms, engagement hooks, profile optimization | Riya Malhotra |
| vpe-advisor | DORA metrics, engineering hiring funnel, delivery throughput | Aarav Mehta |
| website-builder | Landing pages, portfolios, business and multi-page sites | Ethan Cole, Hana Kobayashi |
| youtube-content-engine | Full-stack YouTube engine - scripts, SEO, competitor analysis | Noah Bennett |
| youtube | Scripts, titles, thumbnails, SEO, calendars for faceless channels | Maya Lindqvist |

6 skills have no carrier yet; the weekly review assigns them.
